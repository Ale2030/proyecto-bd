-- Active: 1724451693212@@127.0.0.1@3306@colegio

drop database if exists colegio;
create database colegio;
use colegio;
drop table if exists alumnos;
drop table if exists cursos;
drop table if exists control_auditoria;
drop table if exists cursos_borrados;
drop table if exists alumnos_borrados;
create table cursos(
    id int auto_increment primary key,
    titulo varchar(50) not null, -- check(length(titulo>=2)),
    profesor varchar(50) not null, -- check(length(profesor>=2)),
    dia enum('LUNES','MARTES','MIERCOLES','JUEVES','VIERNES') not null,
    turno enum('MAÑANA','TARDE','NOCHE') not null
);
create table alumnos(
    id int auto_increment primary key,
    nombre varchar(50) not null, -- check(length(nombre>=2)),
    apellido varchar(50) not null, -- check(length(apellido>=2)),
    edad int not null check(edad>=18 and edad<=120),
    id_curso int not null
);
alter table alumnos
    add constraint FK_Alumos_Id_Curso
    foreign key(id_curso)
    references cursos(id);

CREATE TABLE control_auditoria(
    id int AUTO_INCREMENT PRIMARY KEY,
    tabla VARCHAR(50) NOT NULL,
    evento ENUM('INSERT','DELETE','UPDATE') NOT NULL,
    id_registro INT,
    fecha date,
    hora time,
    usuario VARCHAR(50)
);
CREATE TABLE cursos_borrados(
    id int auto_increment primary key,
    titulo varchar(50) not null, 
    profesor varchar(50) not null,
    dia enum('LUNES','MARTES','MIERCOLES','JUEVES','VIERNES') not null,
    turno enum('MAÑANA','TARDE','NOCHE') not null,
    fecha date,
    hora time
);
CREATE TABLE alumnos_borrados(
    id int auto_increment primary key,
    nombre varchar(50) not null,
    apellido varchar(50) not null, 
    edad int not null check(edad>=18 and edad<=120),
    id_curso int not null,
    fecha date,
    hora time
);

DROP TRIGGER IF EXISTS TR_cursos_insert;
CREATE TRIGGER TR_cursos_insert
AFTER INSERT ON cursos FOR EACH ROW
BEGIN
    INSERT INTO control_auditoria
    (tabla,evento,id_registro,fecha,hora,usuario)
    VALUES
    ('cursos','INSERT',NEW.id,CURDATE(),CURTIME(),USER());
END;
DROP TRIGGER IF EXISTS TR_cursos_update;
CREATE TRIGGER TR_cursos_update
AFTER UPDATE ON cursos FOR EACH ROW
BEGIN
    INSERT INTO control_auditoria
    (tabla,evento,id_registro,fecha,hora,usuario)
    VALUES
    ('cursos','UPDATE',NEW.id,CURDATE(),CURTIME(),USER());
END;
DROP TRIGGER IF EXISTS TR_cursos_delete;
CREATE TRIGGER TR_cursos_delete
AFTER DELETE ON cursos FOR EACH ROW
BEGIN
    INSERT INTO control_auditoria
    (tabla,evento,id_registro,fecha,hora,usuario)
    VALUES
    ('cursos','DELETE',OLD.id,CURDATE(),CURTIME(),USER());

    INSERT INTO cursos_borrados
    (titulo,profesor,dia,turno,fecha,hora)
    VALUES
    (OLD.titulo,OLD.profesor,OLD.dia,OLD.turno,CURDATE(),CURTIME());
    
END;
DROP TRIGGER IF EXISTS TR_alumnos_insert;
CREATE TRIGGER TR_alumnos_insert
AFTER INSERT ON alumnos FOR EACH ROW
BEGIN
    INSERT INTO control_auditoria
    (tabla,evento,id_registro,fecha,hora,usuario)
    VALUES
    ('alumnos','INSERT',NEW.id,CURDATE(),CURTIME(),USER());
END;

DROP TRIGGER IF EXISTS TR_alumnos_update;
CREATE TRIGGER TR_alumnos_update
AFTER UPDATE ON alumnos FOR EACH ROW
BEGIN
    INSERT INTO control_auditoria
    (tabla,evento,id_registro,fecha,hora,usuario)
    VALUES
    ('alumnos','UPDATE',NEW.id,CURDATE(),CURTIME(),USER());
END;

DROP TRIGGER IF EXISTS TR_alumnos_delete;
CREATE TRIGGER TR_alumnos_delete
AFTER DELETE ON alumnos FOR EACH ROW
BEGIN
    INSERT INTO control_auditoria
    (tabla,evento,id_registro,fecha,hora,usuario)
    VALUES
    ('alumnos','DELETE',OLD.id,CURDATE(),CURTIME(),USER());

    INSERT INTO alumnos_borrados
    (nombre,apellido,edad,id_curso,fecha,hora)
    VALUES
    (OLD.nombre,OLD.apellido,OLD.edad,OLD.id_curso,CURDATE(),CURTIME());
END;


INSERT INTO cursos(titulo,profesor,dia,turno)
VALUES
('JAVA','Roberto','MIERCOLES','NOCHE'),
('PHP','Francisco','VIERNES','MAÑANA');

INSERT INTO alumnos(nombre,apellido,edad,id_curso)
VALUES
('Juan','Carlos',54,1),
('Alberto','Capriles',32,1);

DELETE FROM cursos WHERE id = 2;
DELETE FROM alumnos WHERE id = 1;

UPDATE cursos set titulo = 'JS' where id =1;
UPDATE alumnos set nombre = 'Roberto' where id = 2;

select * from cursos;
select * from alumnos;
select * from cursos_borrados;
SELECT * from alumnos_borrados;
select * from control_auditoria;
